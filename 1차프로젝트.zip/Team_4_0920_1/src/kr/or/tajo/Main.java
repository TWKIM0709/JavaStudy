package kr.or.tajo;

public class Main {

	public static void main(String[] args) {
		TajoSystem system = new TajoSystem();
		system.run();
	}
}