package kr.or.tajo;

public interface ChargeAble {
	public void charged();
}