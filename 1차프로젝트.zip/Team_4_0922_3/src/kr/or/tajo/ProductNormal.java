package kr.or.tajo;

public class ProductNormal extends Product {
	public ProductNormal(String no, String kind, int price) {
		super(no, kind, price);
	}
	
}

