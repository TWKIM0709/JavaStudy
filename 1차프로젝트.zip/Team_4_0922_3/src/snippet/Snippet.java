package snippet;

public class Snippet {
	//OVER(PARTITION BY ename) AS sname_cnt
}

