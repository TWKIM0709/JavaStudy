package Factory;

public interface Shape {
	void draw();
}
